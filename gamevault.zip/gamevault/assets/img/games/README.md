# Folder Gambar Game

Letakkan file gambar untuk tiap game di sini. Gambar akan otomatis tersimpan
ke folder ini saat kamu upload lewat form "Tambah Game Baru" di halaman
Manajemen Game.

## Sumber gambar yang aman dipakai

- Capsule art / header image resmi dari halaman store Steam game tersebut
  (klik kanan > Save Image, atau gunakan Steam CDN/API resmi)
- Screenshot pribadi dari game yang kamu mainkan sendiri
- Artwork orisinal buatan sendiri

## Hindari

- Cover art / poster resmi dari publisher (CD Projekt RED, FromSoftware, dll)
  untuk ditampilkan ulang di luar tujuan jurnalistik/review — berisiko
  melanggar hak cipta jika dipakai di platform komersial.

## Format & ukuran

- Format: JPG, PNG, atau WEBP
- Maksimal 2MB per file
- Disarankan rasio persegi atau mendekati (misal 512x512 atau 600x800)
  agar tampil rapi sebagai thumbnail di tabel Daftar Game.
