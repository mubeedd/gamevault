<?php 
include 'header_sidebar.php'; 
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Tables</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Ringkasan stok dan kategori untuk referensi cepat</p>
</div>

<div class="card">
    <h3>Ringkasan Stok per Game</h3>
    <table>
        <tr>
            <th>Judul Game</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Sisa Stok Key</th>
            <th>Status Stok</th>
        </tr>
        <?php
        $tampil = mysqli_query($koneksi, "
            SELECT g.judul_game, g.harga, g.stok_key, k.nama_kategori
            FROM game g
            LEFT JOIN kategori k ON g.id_kategori = k.id_kategori
            ORDER BY g.stok_key ASC
        ");
        while ($data = mysqli_fetch_array($tampil)) {
            if ($data['stok_key'] <= 5) {
                $badge = "<span class='badge badge-danger'>Menipis</span>";
            } elseif ($data['stok_key'] <= 20) {
                $badge = "<span class='badge badge-warning'>Sedang</span>";
            } else {
                $badge = "<span class='badge badge-success'>Aman</span>";
            }

            echo "<tr>
                    <td>{$data['judul_game']}</td>
                    <td>" . ($data['nama_kategori'] ?? '-') . "</td>
                    <td>Rp " . number_format($data['harga'], 0, ',', '.') . "</td>
                    <td>{$data['stok_key']}</td>
                    <td>{$badge}</td>
                  </tr>";
        }
        ?>
    </table>
</div>

<div class="card">
    <h3>Jumlah Game per Kategori</h3>
    <table>
        <tr>
            <th>Kategori</th>
            <th>Jumlah Game</th>
            <th>Total Stok Key</th>
        </tr>
        <?php
        $tampil2 = mysqli_query($koneksi, "
            SELECT k.nama_kategori, COUNT(g.id_game) as jumlah_game, SUM(g.stok_key) as total_stok
            FROM kategori k
            LEFT JOIN game g ON g.id_kategori = k.id_kategori
            GROUP BY k.id_kategori
        ");
        while ($data2 = mysqli_fetch_array($tampil2)) {
            echo "<tr>
                    <td>{$data2['nama_kategori']}</td>
                    <td>{$data2['jumlah_game']}</td>
                    <td>" . ($data2['total_stok'] ?? 0) . "</td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>
