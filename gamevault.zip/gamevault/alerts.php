<?php 
include 'header_sidebar.php'; 
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Alerts</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Peringatan operasional berdasarkan kondisi data terkini</p>
</div>

<div class="card">
    <h3>Stok Game Menipis (&le; 5 key)</h3>
    <?php
    $q_stok = mysqli_query($koneksi, "SELECT judul_game, stok_key FROM game WHERE stok_key <= 5 ORDER BY stok_key ASC");
    if (mysqli_num_rows($q_stok) === 0) {
        echo "<div class='alert-box alert-success'><i class='fa-solid fa-circle-check'></i> Semua stok game dalam kondisi aman.</div>";
    } else {
        while ($row = mysqli_fetch_array($q_stok)) {
            echo "<div class='alert-box alert-danger'>
                    <i class='fa-solid fa-triangle-exclamation'></i>
                    Stok <b>{$row['judul_game']}</b> tersisa <b>{$row['stok_key']}</b> key. Segera tambah stok.
                  </div>";
        }
    }
    ?>
</div>

<div class="card">
    <h3>Transaksi Pending Lebih dari 24 Jam</h3>
    <?php
    $q_pending = mysqli_query($koneksi, "
        SELECT id_order, id_user, tanggal_transaksi, total_bayar 
        FROM transaksi 
        WHERE status_order = 'Pending' AND tanggal_transaksi < NOW() - INTERVAL 1 DAY
        ORDER BY tanggal_transaksi ASC
    ");
    if (mysqli_num_rows($q_pending) === 0) {
        echo "<div class='alert-box alert-success'><i class='fa-solid fa-circle-check'></i> Tidak ada transaksi pending yang terlalu lama.</div>";
    } else {
        while ($row = mysqli_fetch_array($q_pending)) {
            echo "<div class='alert-box alert-warning'>
                    <i class='fa-solid fa-clock'></i>
                    Order <b>{$row['id_order']}</b> ({$row['id_user']}) masih Pending sejak {$row['tanggal_transaksi']}.
                    <a href='transaksi.php' style='margin-left:8px; color:#3b7ddd; font-weight:600;'>Tinjau &raquo;</a>
                  </div>";
        }
    }
    ?>
</div>

<div class="card">
    <h3>Pengguna Dibanned</h3>
    <?php
    $q_banned = mysqli_query($koneksi, "SELECT username, email FROM users WHERE status = 'Banned'");
    if (mysqli_num_rows($q_banned) === 0) {
        echo "<div class='alert-box alert-success'><i class='fa-solid fa-circle-check'></i> Tidak ada pengguna yang dibanned saat ini.</div>";
    } else {
        while ($row = mysqli_fetch_array($q_banned)) {
            echo "<div class='alert-box alert-danger'>
                    <i class='fa-solid fa-user-slash'></i>
                    Akun <b>{$row['username']}</b> ({$row['email']}) dalam status Banned.
                  </div>";
        }
    }
    ?>
</div>

<?php include 'footer.php'; ?>
