<?php 
// 1. Panggil file header & sidebar (Otomatis memanggil koneksi.php juga)
include 'header_sidebar.php'; 

// 2. Logika Proses Simpan / Input Data Game ke MySQL
if (isset($_POST['btn_simpan'])) {
    $id_game     = mysqli_real_escape_string($koneksi, $_POST['id_game']);
    $judul_game  = mysqli_real_escape_string($koneksi, $_POST['judul_game']);
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $harga       = intval($_POST['harga']);
    $stok_key    = intval($_POST['stok_key']);
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $gambar_game = null;

    // Proses upload gambar game (opsional)
    if (isset($_FILES['gambar_game']) && $_FILES['gambar_game']['error'] === 0) {
        $ekstensi_izin = ['jpg', 'jpeg', 'png', 'webp'];
        $nama_asli = $_FILES['gambar_game']['name'];
        $ekstensi  = strtolower(pathinfo($nama_asli, PATHINFO_EXTENSION));
        $ukuran    = $_FILES['gambar_game']['size'];

        if (!in_array($ekstensi, $ekstensi_izin)) {
            echo "<script>alert('Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.'); window.location='manajemen_game.php';</script>";
            exit;
        }
        if ($ukuran > 2 * 1024 * 1024) { // maksimal 2MB
            echo "<script>alert('Ukuran gambar terlalu besar. Maksimal 2MB.'); window.location='manajemen_game.php';</script>";
            exit;
        }

        $nama_file = $id_game . '_' . time() . '.' . $ekstensi;
        $folder_tujuan = 'assets/img/games/' . $nama_file;

        if (move_uploaded_file($_FILES['gambar_game']['tmp_name'], $folder_tujuan)) {
            $gambar_game = $nama_file;
        }
    }

    if ($gambar_game) {
        $query = "INSERT INTO game (id_game, judul_game, id_kategori, harga, stok_key, deskripsi, gambar_game) 
                  VALUES ('$id_game', '$judul_game', '$id_kategori', '$harga', '$stok_key', '$deskripsi', '$gambar_game')";
    } else {
        $query = "INSERT INTO game (id_game, judul_game, id_kategori, harga, stok_key, deskripsi) 
                  VALUES ('$id_game', '$judul_game', '$id_kategori', '$harga', '$stok_key', '$deskripsi')";
    }
    
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data Game Berhasil Disimpan ke MySQL!'); window.location='manajemen_game.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan: " . mysqli_error($koneksi) . "');</script>";
    }
}

// 3. Logika Proses Update / Edit Data Game
if (isset($_POST['btn_update'])) {
    $id_game_lama = mysqli_real_escape_string($koneksi, $_POST['id_game_lama']);
    $id_game     = mysqli_real_escape_string($koneksi, $_POST['id_game']);
    $judul_game  = mysqli_real_escape_string($koneksi, $_POST['judul_game']);
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $harga       = intval($_POST['harga']);
    $stok_key    = intval($_POST['stok_key']);
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);

    // Ambil data gambar lama dari database (untuk dipertahankan jika tidak diganti)
    $cek_lama = mysqli_query($koneksi, "SELECT gambar_game FROM game WHERE id_game='$id_game_lama'");
    $baris_lama = mysqli_fetch_array($cek_lama);
    $gambar_game = $baris_lama['gambar_game'];

    // Proses upload gambar baru jika ada (opsional, menggantikan gambar lama)
    if (isset($_FILES['gambar_game']) && $_FILES['gambar_game']['error'] === 0) {
        $ekstensi_izin = ['jpg', 'jpeg', 'png', 'webp'];
        $nama_asli = $_FILES['gambar_game']['name'];
        $ekstensi  = strtolower(pathinfo($nama_asli, PATHINFO_EXTENSION));
        $ukuran    = $_FILES['gambar_game']['size'];

        if (!in_array($ekstensi, $ekstensi_izin)) {
            echo "<script>alert('Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.'); window.location='manajemen_game.php';</script>";
            exit;
        }
        if ($ukuran > 2 * 1024 * 1024) { // maksimal 2MB
            echo "<script>alert('Ukuran gambar terlalu besar. Maksimal 2MB.'); window.location='manajemen_game.php';</script>";
            exit;
        }

        $nama_file = $id_game . '_' . time() . '.' . $ekstensi;
        $folder_tujuan = 'assets/img/games/' . $nama_file;

        if (move_uploaded_file($_FILES['gambar_game']['tmp_name'], $folder_tujuan)) {
            // Hapus gambar lama dari folder jika ada gambar baru yang berhasil diupload
            if (!empty($gambar_game) && file_exists('assets/img/games/' . $gambar_game)) {
                unlink('assets/img/games/' . $gambar_game);
            }
            $gambar_game = $nama_file;
        }
    }

    $query = "UPDATE game SET 
                id_game = '$id_game', 
                judul_game = '$judul_game', 
                id_kategori = '$id_kategori', 
                harga = '$harga', 
                stok_key = '$stok_key', 
                deskripsi = '$deskripsi', 
                gambar_game = " . ($gambar_game ? "'$gambar_game'" : "NULL") . " 
              WHERE id_game = '$id_game_lama'";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data Game Berhasil Diupdate!'); window.location='manajemen_game.php';</script>";
    } else {
        echo "<script>alert('Gagal mengupdate: " . mysqli_error($koneksi) . "');</script>";
    }
}

// 4. Logika Proses Hapus Data Game
if (isset($_GET['hapus'])) {
    $id_hapus = mysqli_real_escape_string($koneksi, $_GET['hapus']);

    // Hapus juga file gambar terkait dari folder jika ada
    $cek = mysqli_query($koneksi, "SELECT gambar_game FROM game WHERE id_game='$id_hapus'");
    if ($baris = mysqli_fetch_array($cek)) {
        if (!empty($baris['gambar_game']) && file_exists('assets/img/games/' . $baris['gambar_game'])) {
            unlink('assets/img/games/' . $baris['gambar_game']);
        }
    }

    mysqli_query($koneksi, "DELETE FROM game WHERE id_game='$id_hapus'");
    echo "<script>alert('Data Game Berhasil Dihapus!'); window.location='manajemen_game.php';</script>";
}
?>

<div class="card">
    <h3>Tambah Game Baru</h3>
    <form action="" method="POST" enctype="multipart/form-data" style="margin-top: 15px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>ID Game</label>
                <input type="text" name="id_game" placeholder="Contoh: GM-004" required>
            </div>
            <div class="form-group">
                <label>Judul Game</label>
                <input type="text" name="judul_game" placeholder="Masukkan judul game" required>
            </div>
            <div class="form-group">
                <label>Kategori</label>
                <select name="id_kategori" required>
                    <?php
                    // Mengambil daftar kategori dinamis dari tabel MySQL
                    $kat = mysqli_query($koneksi, "SELECT * FROM kategori");
                    while($k = mysqli_fetch_array($kat)){
                        echo "<option value='{$k['id_kategori']}'>{$k['nama_kategori']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Harga (Rupiah)</label>
                <input type="number" name="harga" placeholder="Contoh: 500000" required>
            </div>
            <div class="form-group">
                <label>Stok Key</label>
                <input type="number" name="stok_key" placeholder="Contoh: 10" required>
            </div>
            <div class="form-group">
                <label>Deskripsi</label>
                <input type="text" name="deskripsi" placeholder="Deskripsi singkat game">
            </div>
            <div class="form-group" style="grid-column: 1 / -1;">
                <label>Gambar Game (opsional, JPG/PNG/WEBP, maks 2MB)</label>
                <input type="file" name="gambar_game" accept=".jpg,.jpeg,.png,.webp">
            </div>
        </div>
        <button type="submit" name="btn_simpan" class="btn btn-primary" style="margin-top: 15px;">Simpan Game</button>
    </form>
</div>

<div class="card">
    <h3>Daftar Game</h3>
    <table>
        <tr>
            <th>Gambar</th>
            <th>ID</th>
            <th>Judul Game</th>
            <th>Harga</th>
            <th>Stok Key</th>
            <th>Aksi</th>
        </tr>
        <?php
        // Mengambil data game real dari database gamevault_db
        $tampil = mysqli_query($koneksi, "SELECT * FROM game");
        while ($data = mysqli_fetch_array($tampil)) {
            if (!empty($data['gambar_game']) && file_exists('assets/img/games/' . $data['gambar_game'])) {
                $thumb = "<img src='assets/img/games/{$data['gambar_game']}' class='game-thumb' alt='{$data['judul_game']}'>";
            } else {
                $thumb = "<div class='game-thumb game-thumb-placeholder'><i class='fa-solid fa-image'></i></div>";
            }

            $data_js = htmlspecialchars(json_encode($data), ENT_QUOTES, 'UTF-8');

            echo "<tr>
                    <td>{$thumb}</td>
                    <td>{$data['id_game']}</td>
                    <td>{$data['judul_game']}</td>
                    <td>Rp " . number_format($data['harga'], 0, ',', '.') . "</td>
                    <td>{$data['stok_key']}</td>
                    <td>
                        <button type='button' class='btn btn-primary' onclick='bukaModalEdit({$data_js})'>Edit</button>
                        <button type='button' class='btn btn-danger' onclick=\"bukaModalHapus('{$data['id_game']}', '{$data['judul_game']}')\">Hapus</button>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</div>

<!-- Modal Edit / Update Game -->
<div class="modal-overlay" id="modalEditGame">
    <div class="modal-box" style="max-width: 600px;">
        <h4><i class="fa-solid fa-pen-to-square"></i> Edit Data Game</h4>
        <form action="" method="POST" enctype="multipart/form-data" style="margin-top: 15px;">
            <input type="hidden" name="id_game_lama" id="edit_id_game_lama">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>ID Game</label>
                    <input type="text" name="id_game" id="edit_id_game" required>
                </div>
                <div class="form-group">
                    <label>Judul Game</label>
                    <input type="text" name="judul_game" id="edit_judul_game" required>
                </div>
                <div class="form-group">
                    <label>Kategori</label>
                    <select name="id_kategori" id="edit_id_kategori" required>
                        <?php
                        $kat_edit = mysqli_query($koneksi, "SELECT * FROM kategori");
                        while($k = mysqli_fetch_array($kat_edit)){
                            echo "<option value='{$k['id_kategori']}'>{$k['nama_kategori']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Harga (Rupiah)</label>
                    <input type="number" name="harga" id="edit_harga" required>
                </div>
                <div class="form-group">
                    <label>Stok Key</label>
                    <input type="number" name="stok_key" id="edit_stok_key" required>
                </div>
                <div class="form-group">
                    <label>Deskripsi</label>
                    <input type="text" name="deskripsi" id="edit_deskripsi">
                </div>
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Gambar Game (opsional, biarkan kosong jika tidak ingin mengganti)</label>
                    <input type="file" name="gambar_game" accept=".jpg,.jpeg,.png,.webp">
                </div>
            </div>
            <div class="modal-actions" style="margin-top: 15px;">
                <button type="button" class="btn btn-secondary" onclick="tutupModalEdit()">Batal</button>
                <button type="submit" name="btn_update" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Konfirmasi Hapus Game -->
<div class="modal-overlay" id="modalHapusGame">
    <div class="modal-box">
        <h4><i class="fa-solid fa-triangle-exclamation"></i> Hapus Game?</h4>
        <p id="teksModalHapus">Apakah Anda yakin ingin menghapus game ini? Tindakan ini tidak dapat dibatalkan.</p>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="tutupModalHapus()">Batal</button>
            <a href="#" id="linkKonfirmasiHapus" class="btn btn-danger">Ya, Hapus</a>
        </div>
    </div>
</div>

<script>
function bukaModalEdit(data) {
    document.getElementById('edit_id_game_lama').value = data.id_game;
    document.getElementById('edit_id_game').value = data.id_game;
    document.getElementById('edit_judul_game').value = data.judul_game;
    document.getElementById('edit_id_kategori').value = data.id_kategori;
    document.getElementById('edit_harga').value = data.harga;
    document.getElementById('edit_stok_key').value = data.stok_key;
    document.getElementById('edit_deskripsi').value = data.deskripsi;
    document.getElementById('modalEditGame').classList.add('active');
}
function tutupModalEdit() {
    document.getElementById('modalEditGame').classList.remove('active');
}
function bukaModalHapus(idGame, judulGame) {
    document.getElementById('teksModalHapus').innerText = 'Apakah Anda yakin ingin menghapus "' + judulGame + '"? Tindakan ini tidak dapat dibatalkan.';
    document.getElementById('linkKonfirmasiHapus').href = 'manajemen_game.php?hapus=' + encodeURIComponent(idGame);
    document.getElementById('modalHapusGame').classList.add('active');
}
function tutupModalHapus() {
    document.getElementById('modalHapusGame').classList.remove('active');
}
</script>

<?php 
// 5. Panggil file footer untuk menutup tag HTML
include 'footer.php'; 
?>