<?php 
include 'header_sidebar.php'; 
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Components</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Referensi komponen visual yang dipakai di seluruh halaman GameVault</p>
</div>

<div class="card">
    <h3>Badge Status</h3>
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <span class="badge badge-success">Selesai</span>
        <span class="badge badge-warning">Pending</span>
        <span class="badge badge-danger">Batal</span>
    </div>
</div>

<div class="card">
    <h3>Tombol (Buttons)</h3>
    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button class="btn btn-primary">Simpan</button>
        <button class="btn btn-danger">Hapus</button>
    </div>
</div>

<div class="card">
    <h3>Alert Box</h3>
    <div class="alert-box alert-success"><i class="fa-solid fa-circle-check"></i> Contoh notifikasi berhasil.</div>
    <div class="alert-box alert-warning"><i class="fa-solid fa-clock"></i> Contoh notifikasi peringatan.</div>
    <div class="alert-box alert-danger"><i class="fa-solid fa-triangle-exclamation"></i> Contoh notifikasi bahaya.</div>
</div>

<div class="card">
    <h3>Form Input</h3>
    <div style="max-width: 400px;">
        <div class="form-group">
            <label>Contoh Label</label>
            <input type="text" placeholder="Contoh placeholder input">
        </div>
        <div class="form-group">
            <label>Contoh Select</label>
            <select>
                <option>Pilihan Satu</option>
                <option>Pilihan Dua</option>
            </select>
        </div>
    </div>
</div>

<div class="card">
    <h3>Card</h3>
    <p style="color:#64748b; font-size: 13.5px;">
        Komponen <code>.card</code> ini sendiri adalah wadah utama yang dipakai di hampir semua halaman GameVault,
        termasuk halaman ini.
    </p>
</div>

<?php include 'footer.php'; ?>
