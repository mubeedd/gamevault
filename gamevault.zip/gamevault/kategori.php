<?php 
include 'header_sidebar.php'; 

// PROSES SIMPAN / INPUT KATEGORI BARU
if (isset($_POST['btn_kategori'])) {
    $id_kat   = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama_kat = mysqli_real_escape_string($koneksi, $_POST['nama_kategori']);

    $query = "INSERT INTO kategori (id_kategori, nama_kategori) VALUES ('$id_kat', '$nama_kat')";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Kategori Baru Berhasil Ditambahkan!'); window.location='kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah kategori: " . mysqli_error($koneksi) . "');</script>";
    }
}
?>

<div class="card">
    <h3>Tambah Kategori Baru</h3>
    <form action="" method="POST" style="margin-top: 15px; display: flex; gap: 15px; align-items: flex-end;">
        <div class="form-group" style="flex:1; margin-bottom:0;">
            <label>ID Kategori</label>
            <input type="text" name="id_kategori" placeholder="Contoh: CAT-04" required>
        </div>
        <div class="form-group" style="flex:2; margin-bottom:0;">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" placeholder="Contoh: Simulator / Sports" required>
        </div>
        <button type="submit" name="btn_kategori" class="btn btn-primary" style="height:40px;">Tambah Kategori</button>
    </form>
</div>

<div class="card">
    <h3>Daftar Kategori Game (Live MySQL)</h3>
    <table>
        <tr>
            <th>ID Kategori</th>
            <th>Nama Kategori</th>
        </tr>
        <?php
        $tampil = mysqli_query($koneksi, "SELECT * FROM kategori");
        while ($data = mysqli_fetch_array($tampil)) {
            echo "<tr>
                    <td>{$data['id_kategori']}</td>
                    <td>{$data['nama_kategori']}</td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>