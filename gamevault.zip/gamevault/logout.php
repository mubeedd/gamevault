<?php
session_start();
// Menghapus semua session yang terdaftar
session_destroy();

echo "<script>alert('Anda telah berhasil logout!'); window.location='login.php';</script>";
exit;
?>