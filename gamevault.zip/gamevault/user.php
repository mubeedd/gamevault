<?php 
include 'header_sidebar.php'; 
?>

<div class="card">
    <h3>Data Akun Pengguna & Administrator</h3>
    <table>
        <tr>
            <th>ID User</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status Akun</th>
        </tr>
        <?php
        $tampil = mysqli_query($koneksi, "SELECT * FROM users");
        while ($data = mysqli_fetch_array($tampil)) {
            echo "<tr>
                    <td>{$data['id_user']}</td>
                    <td>{$data['username']}</td>
                    <td>{$data['email']}</td>
                    <td><b>{$data['role']}</b></td>
                    <td><span class='badge badge-success'>{$data['status']}</span></td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>