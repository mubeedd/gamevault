<?php 
include 'header_sidebar.php'; 

// Proses pencarian game berdasarkan filter yang diisi
$where = [];
if (!empty($_GET['cari_judul'])) {
    $kw = mysqli_real_escape_string($koneksi, $_GET['cari_judul']);
    $where[] = "g.judul_game LIKE '%$kw%'";
}
if (!empty($_GET['filter_kategori'])) {
    $kat = mysqli_real_escape_string($koneksi, $_GET['filter_kategori']);
    $where[] = "g.id_kategori = '$kat'";
}
if (!empty($_GET['filter_harga_max'])) {
    $harga_max = intval($_GET['filter_harga_max']);
    $where[] = "g.harga <= $harga_max";
}
$klausa_where = count($where) > 0 ? "WHERE " . implode(' AND ', $where) : "";
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Forms</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Pencarian & filter cepat untuk katalog game</p>
</div>

<div class="card">
    <h3>Cari Game</h3>
    <form action="" method="GET" style="margin-top: 15px;">
        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 15px; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label>Judul Game</label>
                <input type="text" name="cari_judul" value="<?= htmlspecialchars($_GET['cari_judul'] ?? ''); ?>" placeholder="Ketik judul game...">
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <label>Kategori</label>
                <select name="filter_kategori">
                    <option value="">Semua Kategori</option>
                    <?php
                    $kat = mysqli_query($koneksi, "SELECT * FROM kategori");
                    while ($k = mysqli_fetch_array($kat)) {
                        $sel = (isset($_GET['filter_kategori']) && $_GET['filter_kategori'] == $k['id_kategori']) ? 'selected' : '';
                        echo "<option value='{$k['id_kategori']}' {$sel}>{$k['nama_kategori']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <label>Harga Maksimal</label>
                <input type="number" name="filter_harga_max" value="<?= htmlspecialchars($_GET['filter_harga_max'] ?? ''); ?>" placeholder="Contoh: 500000">
            </div>
            <button type="submit" class="btn btn-primary" style="height: 41px;">Cari</button>
        </div>
    </form>
</div>

<div class="card">
    <h3>Hasil Pencarian</h3>
    <table>
        <tr>
            <th>ID</th>
            <th>Judul Game</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Stok Key</th>
        </tr>
        <?php
        $query = "
            SELECT g.id_game, g.judul_game, g.harga, g.stok_key, k.nama_kategori
            FROM game g
            LEFT JOIN kategori k ON g.id_kategori = k.id_kategori
            $klausa_where
            ORDER BY g.judul_game ASC
        ";
        $tampil = mysqli_query($koneksi, $query);
        if (mysqli_num_rows($tampil) === 0) {
            echo "<tr><td colspan='5' style='text-align:center; color:#94a3b8;'>Tidak ada game yang cocok dengan filter.</td></tr>";
        }
        while ($data = mysqli_fetch_array($tampil)) {
            echo "<tr>
                    <td>{$data['id_game']}</td>
                    <td>{$data['judul_game']}</td>
                    <td>" . ($data['nama_kategori'] ?? '-') . "</td>
                    <td>Rp " . number_format($data['harga'], 0, ',', '.') . "</td>
                    <td>{$data['stok_key']}</td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>
