<?php 
include 'header_sidebar.php'; 

// Proses Update Pengaturan Toko
if (isset($_POST['btn_simpan_setting'])) {
    $nama_toko      = mysqli_real_escape_string($koneksi, $_POST['nama_toko']);
    $email_kontak   = mysqli_real_escape_string($koneksi, $_POST['email_kontak']);
    $nomor_wa       = mysqli_real_escape_string($koneksi, $_POST['nomor_wa']);
    $deskripsi_toko = mysqli_real_escape_string($koneksi, $_POST['deskripsi_toko']);

    $query = "UPDATE pengaturan_toko SET 
                nama_toko='$nama_toko', 
                email_kontak='$email_kontak', 
                nomor_wa='$nomor_wa', 
                deskripsi_toko='$deskripsi_toko' 
              WHERE id=1";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Pengaturan toko berhasil disimpan!'); window.location='settings.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan pengaturan: " . mysqli_error($koneksi) . "');</script>";
    }
}

// Ambil data pengaturan saat ini (kalau belum ada baris, pakai nilai default kosong)
$cek_setting = mysqli_query($koneksi, "SELECT * FROM pengaturan_toko WHERE id=1");
$setting = $cek_setting ? mysqli_fetch_array($cek_setting) : null;
if (!$setting) {
    $setting = ['nama_toko' => 'GameVault', 'email_kontak' => '', 'nomor_wa' => '', 'deskripsi_toko' => ''];
}
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Settings</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Atur informasi dasar toko GameVault</p>
</div>

<div style="max-width: 600px;">
    <div class="card">
        <h3><i class="fa-solid fa-store" style="color: #3b7ddd; margin-right: 8px;"></i> Informasi Toko</h3>

        <form action="" method="POST" style="margin-top: 20px;">
            <div class="form-group">
                <label>Nama Toko</label>
                <input type="text" name="nama_toko" value="<?= htmlspecialchars($setting['nama_toko']); ?>" required>
            </div>

            <div class="form-group">
                <label>Email Kontak</label>
                <input type="email" name="email_kontak" value="<?= htmlspecialchars($setting['email_kontak']); ?>" placeholder="admin@gamevault.com">
            </div>

            <div class="form-group">
                <label>Nomor WhatsApp Layanan Pelanggan</label>
                <input type="text" name="nomor_wa" value="<?= htmlspecialchars($setting['nomor_wa']); ?>" placeholder="Contoh: 081234567890">
            </div>

            <div class="form-group">
                <label>Deskripsi Toko</label>
                <textarea name="deskripsi_toko" rows="4" placeholder="Deskripsi singkat tentang toko"><?= htmlspecialchars($setting['deskripsi_toko']); ?></textarea>
            </div>

            <button type="submit" name="btn_simpan_setting" class="btn btn-primary" style="margin-top: 10px;">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan
            </button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
