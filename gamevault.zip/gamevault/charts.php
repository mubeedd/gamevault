<?php 
include 'header_sidebar.php'; 

// Data pendapatan per bulan (6 bulan terakhir) dari transaksi yang Selesai
$q_bulanan = mysqli_query($koneksi, "
    SELECT DATE_FORMAT(tanggal_transaksi, '%Y-%m') as bulan, SUM(total_bayar) as total
    FROM transaksi
    WHERE status_order = 'Selesai'
    GROUP BY bulan
    ORDER BY bulan ASC
");
$label_bulan = [];
$data_pendapatan = [];
while ($row = mysqli_fetch_array($q_bulanan)) {
    $label_bulan[] = $row['bulan'];
    $data_pendapatan[] = (int) $row['total'];
}

// Data jumlah transaksi per status
$q_status = mysqli_query($koneksi, "SELECT status_order, COUNT(*) as jumlah FROM transaksi GROUP BY status_order");
$label_status = [];
$data_status = [];
while ($row = mysqli_fetch_array($q_status)) {
    $label_status[] = $row['status_order'];
    $data_status[] = (int) $row['jumlah'];
}

// Data game terlaris berdasarkan jumlah terjual di detail_transaksi
$q_terlaris = mysqli_query($koneksi, "
    SELECT g.judul_game, SUM(dt.jumlah) as total_terjual
    FROM detail_transaksi dt
    JOIN game g ON dt.id_game = g.id_game
    GROUP BY g.id_game
    ORDER BY total_terjual DESC
    LIMIT 5
");
$label_game = [];
$data_terjual = [];
while ($row = mysqli_fetch_array($q_terlaris)) {
    $label_game[] = $row['judul_game'];
    $data_terjual[] = (int) $row['total_terjual'];
}
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Charts</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Visualisasi penjualan berdasarkan data transaksi nyata</p>
</div>

<div class="card">
    <h3>Pendapatan per Bulan (Transaksi Selesai)</h3>
    <canvas id="chartPendapatan" height="90"></canvas>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <h3>Transaksi per Status</h3>
        <canvas id="chartStatus" height="220"></canvas>
    </div>
    <div class="card">
        <h3>5 Game Terlaris</h3>
        <canvas id="chartTerlaris" height="220"></canvas>
    </div>
</div>

<script>
new Chart(document.getElementById('chartPendapatan'), {
    type: 'line',
    data: {
        labels: <?= json_encode($label_bulan); ?>,
        datasets: [{
            label: 'Pendapatan (Rp)',
            data: <?= json_encode($data_pendapatan); ?>,
            borderColor: '#3b7ddd',
            backgroundColor: 'rgba(59, 125, 221, 0.15)',
            fill: true,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode($label_status); ?>,
        datasets: [{
            data: <?= json_encode($data_status); ?>,
            backgroundColor: ['#f59e0b', '#10b981', '#ef4444']
        }]
    },
    options: { responsive: true }
});

new Chart(document.getElementById('chartTerlaris'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($label_game); ?>,
        datasets: [{
            label: 'Jumlah Terjual',
            data: <?= json_encode($data_terjual); ?>,
            backgroundColor: '#3b7ddd'
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>

<?php include 'footer.php'; ?>
