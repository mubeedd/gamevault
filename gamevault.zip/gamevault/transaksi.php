<?php 
include 'header_sidebar.php'; 

// Proses Update Status Order
if (isset($_POST['btn_update_status'])) {
    $id_order = mysqli_real_escape_string($koneksi, $_POST['id_order']);
    $status_baru = mysqli_real_escape_string($koneksi, $_POST['status_order']);

    $status_diizinkan = ['Pending', 'Selesai', 'Batal'];
    if (in_array($status_baru, $status_diizinkan)) {
        $query = "UPDATE transaksi SET status_order='$status_baru' WHERE id_order='$id_order'";
        if (mysqli_query($koneksi, $query)) {
            echo "<script>alert('Status transaksi berhasil diupdate!'); window.location='transaksi.php';</script>";
        } else {
            echo "<script>alert('Gagal update status: " . mysqli_error($koneksi) . "');</script>";
        }
    }
    exit;
}

// Proses Hapus Transaksi
if (isset($_GET['hapus'])) {
    $id_hapus = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    // detail_transaksi terhubung dengan ON DELETE CASCADE, jadi otomatis ikut terhapus
    mysqli_query($koneksi, "DELETE FROM transaksi WHERE id_order='$id_hapus'");
    echo "<script>alert('Transaksi berhasil dihapus!'); window.location='transaksi.php';</script>";
    exit;
}
?>

<div class="card">
    <h3>Daftar Transaksi Order Masuk (Live Data)</h3>
    <table>
        <tr>
            <th>ID Order</th>
            <th>ID Pembeli</th>
            <th>Tanggal Transaksi</th>
            <th>Total Bayar</th>
            <th>Status</th>
            <th>Ubah Status</th>
            <th>Aksi</th>
        </tr>
        <?php
        $tampil = mysqli_query($koneksi, "SELECT * FROM transaksi ORDER BY tanggal_transaksi DESC");
        while ($data = mysqli_fetch_array($tampil)) {
            // Logika warna status order
            if ($data['status_order'] == 'Selesai') {
                $status_class = 'badge-success';
            } elseif ($data['status_order'] == 'Batal') {
                $status_class = 'badge-danger';
            } else {
                $status_class = 'badge-warning';
            }

            $opsi_status = ['Pending', 'Selesai', 'Batal'];
            $opsi_html = '';
            foreach ($opsi_status as $opsi) {
                $selected = ($opsi == $data['status_order']) ? 'selected' : '';
                $opsi_html .= "<option value='{$opsi}' {$selected}>{$opsi}</option>";
            }

            echo "<tr>
                    <td>{$data['id_order']}</td>
                    <td>{$data['id_user']}</td>
                    <td>{$data['tanggal_transaksi']}</td>
                    <td>Rp " . number_format($data['total_bayar'], 0, ',', '.') . "</td>
                    <td><span class='badge {$status_class}'>{$data['status_order']}</span></td>
                    <td>
                        <form action='' method='POST' style='display:flex; gap:8px; align-items:center;'>
                            <input type='hidden' name='id_order' value='{$data['id_order']}'>
                            <select name='status_order' style='width:auto; padding:8px 10px;'>
                                {$opsi_html}
                            </select>
                            <button type='submit' name='btn_update_status' class='btn btn-primary' style='padding:8px 14px;'>Update</button>
                        </form>
                    </td>
                    <td>
                        <a href='transaksi.php?hapus={$data['id_order']}' class='btn btn-danger' onclick='return confirm(\"Hapus transaksi {$data['id_order']}? Detail item di dalamnya akan ikut terhapus.\")'>Hapus</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>