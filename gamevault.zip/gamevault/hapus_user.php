<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['admin_vault'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];

// Proses Hapus
$delete = mysqli_query($koneksi, "DELETE FROM users WHERE id = '$id'");

if ($delete) {
    echo "<script>
            alert('User berhasil dihapus!');
            window.location.href='user.php';
          </script>";
} else {
    echo "<script>
            alert('Gagal menghapus data');
            window.location.href='user.php';
          </script>";
}
?>