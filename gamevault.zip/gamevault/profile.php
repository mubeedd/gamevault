<?php 
include 'header_sidebar.php'; 

$username_aktif = $_SESSION['admin_vault'];

// Proses Update Profil (Email & Password)
if (isset($_POST['btn_update_profil'])) {
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);

    if (!empty($_POST['password_baru'])) {
        // Jika admin mengisi password baru, sekalian update password
        $password_baru = mysqli_real_escape_string($koneksi, $_POST['password_baru']);
        $query = "UPDATE users SET email='$email', password='$password_baru' WHERE username='$username_aktif'";
    } else {
        // Jika password dikosongkan, hanya update email
        $query = "UPDATE users SET email='$email' WHERE username='$username_aktif'";
    }

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Profil berhasil diperbarui!'); window.location='profile.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui profil: " . mysqli_error($koneksi) . "');</script>";
    }
}

// Ambil data profil admin yang sedang login
$q_profil = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username_aktif'");
$profil = mysqli_fetch_array($q_profil);
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Profile</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Kelola informasi akun administrator kamu</p>
</div>

<div style="max-width: 600px;">
    <div class="card">
        <h3><i class="fa-solid fa-user-gear" style="color: #3b7ddd; margin-right: 8px;"></i> Akun Saya</h3>

        <form action="" method="POST" style="margin-top: 20px;">
            <div class="form-group">
                <label>Username</label>
                <input type="text" value="<?= htmlspecialchars($profil['username']); ?>" disabled style="background-color:#f4f6f9; color:#94a3b8;">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($profil['email']); ?>" required>
            </div>

            <div class="form-group">
                <label>Password Baru (kosongkan jika tidak ingin diubah)</label>
                <input type="password" name="password_baru" placeholder="••••••••">
            </div>

            <div class="form-group">
                <label>Role</label>
                <input type="text" value="<?= htmlspecialchars($profil['role']); ?>" disabled style="background-color:#f4f6f9; color:#94a3b8;">
            </div>

            <button type="submit" name="btn_update_profil" class="btn btn-primary" style="margin-top: 10px;">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
            </button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
