<?php 
include 'header_sidebar.php'; 
?>

<div class="card">
    <h3>Laporan Rekap Penjualan Real-Time</h3>
    <p style="color: #7f8c8d; font-size: 14px; margin-bottom: 15px;">
        Data laporan keuangan ini dihitung otomatis berdasarkan akumulasi transaksi di dalam database MySQL.
    </p>
    
    <table style="margin-top: 10px;">
        <tr>
            <th>Status Transaksi</th>
            <th>Jumlah Order</th>
            <th>Total Pendapatan (Rupiah)</th>
        </tr>
        <?php
        $tampil = mysqli_query($koneksi, "SELECT status_order, COUNT(*) as jumlah_order, SUM(total_bayar) as total_rupiah FROM transaksi GROUP BY status_order");
        
        while ($data = mysqli_fetch_array($tampil)) {
            echo "<tr>
                    <td><b>{$data['status_order']}</b></td>
                    <td>{$data['jumlah_order']} Transaksi</td>
                    <td>Rp " . number_format($data['total_rupiah'], 0, ',', '.') . "</td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>