<?php 
include 'header_sidebar.php'; 
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Modals</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Modal konfirmasi dipakai untuk menggantikan popup bawaan browser saat menghapus data</p>
</div>

<div class="card">
    <h3>Contoh Modal Konfirmasi</h3>
    <p style="color:#64748b; font-size: 13.5px; margin-bottom: 16px;">
        Modal ini sudah dipakai secara nyata di halaman <a href="manajemen_game.php" style="color:#3b7ddd; font-weight:600;">Manajemen Game</a> 
        saat menghapus data game, supaya tampilannya konsisten dengan desain GameVault (bukan popup default browser).
    </p>
    <button type="button" class="btn btn-danger" onclick="document.getElementById('modalContoh').classList.add('active')">
        Coba Buka Modal
    </button>
</div>

<div class="modal-overlay" id="modalContoh">
    <div class="modal-box">
        <h4><i class="fa-solid fa-triangle-exclamation"></i> Contoh Konfirmasi</h4>
        <p>Ini adalah contoh tampilan modal konfirmasi yang dipakai di seluruh halaman GameVault.</p>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('modalContoh').classList.remove('active')">Batal</button>
            <button type="button" class="btn btn-danger" onclick="document.getElementById('modalContoh').classList.remove('active')">Ya, Lanjutkan</button>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
