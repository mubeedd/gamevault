<?php 
include 'header_sidebar.php'; 

// Proses Simpan Data saat Tombol Di-klik
if (isset($_POST['simpan_user'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $email    = mysqli_real_escape_string($koneksi, $_POST['email']);
    $role     = mysqli_real_escape_string($koneksi, $_POST['role']);

    // Catatan: sistem login GameVault saat ini menyimpan & mencocokkan password
    // sebagai plain text (lihat login.php), jadi password di sini juga disimpan
    // apa adanya agar konsisten dan bisa dipakai login.
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Query Insert ke Database (kolom mengikuti struktur tabel users yang sebenarnya)
    $insert = mysqli_query($koneksi, "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')");

    if ($insert) {
        echo "<script>
                alert('User baru berhasil ditambahkan!');
                window.location.href='user.php';
              </script>";
    } else {
        echo "<script>alert('Gagal menambahkan user: " . mysqli_error($koneksi) . "');</script>";
    }
}
?>

<div style="margin-bottom: 25px;">
    <h1 style="color: #fff; font-size: 22px; font-weight: 700;">Add New User</h1>
    <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Tambahkan akun operator atau administrator baru</p>
</div>

<div style="max-width: 600px;">
    <div class="card">
        <h3><i class="fa-solid fa-user-plus" style="color: #3b7ddd; margin-right: 8px;"></i> Form Pengguna Baru</h3>
        
        <form action="" method="POST" style="margin-top: 20px;">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Contoh: admin_vault" required autocomplete="off">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="Contoh: user@gamevault.com" required>
            </div>

            <div class="form-group">
                <label>Password Akun</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>

            <div class="form-group">
                <label>Role Akses</label>
                <select name="role" required>
                    <option value="" disabled selected>-- Pilih Hak Akses --</option>
                    <option value="Admin">Admin (Akses Penuh)</option>
                    <option value="Customer">Customer</option>
                </select>
            </div>

            <div style="margin-top: 25px; display: flex; gap: 10px;">
                <button type="submit" name="simpan_user" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan User
                </button>
                <a href="user.php" class="btn btn-danger" style="text-decoration: none; line-height: 20px;">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>