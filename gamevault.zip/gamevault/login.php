<?php
// Mengaktifkan session PHP
session_start();
include 'koneksi.php';

if (isset($_POST['btn_login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Memeriksa ke database apakah akun adminnya ada dan aktif
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='Admin' AND status='Aktif'";
    $login = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($login) > 0) {
        // Jika akun ditemukan, buat session dengan nama 'admin_vault'
        $_SESSION['admin_vault'] = $username;
        echo "<script>alert('Login Berhasil! Selamat Datang Admin.'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Username atau Password Salah!'); window.location='login.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameVault - Login Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">
    <div class="login-bg-glow"></div>

    <div class="login-wrapper">
        <div class="login-brand">
            <div class="login-brand-mark">
                <img src="assets/img/logo.jpg" alt="GameVault">
            </div>
            <h1>GameVault</h1>
            <p>Sistem Administrator</p>
        </div>

        <div class="login-card">
            <h2>Masuk ke Dashboard</h2>
            <p class="login-subtitle">Khusus untuk admin yang terdaftar dan aktif.</p>

            <form action="" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <div class="input-icon-wrap">
                        <svg class="input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        <input id="username" type="text" name="username" placeholder="Masukkan username admin" autocomplete="username" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-icon-wrap">
                        <svg class="input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        <input id="password" type="password" name="password" placeholder="Masukkan password" autocomplete="current-password" required>
                    </div>
                </div>
                <button type="submit" name="btn_login" class="btn btn-primary">Login ke Dashboard</button>
            </form>
        </div>

        <p class="login-footnote">&copy; <?php echo date('Y'); ?> GameVault. Akses terbatas untuk administrator.</p>
    </div>
</body>
</html>