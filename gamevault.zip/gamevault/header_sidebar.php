<?php
session_start();
include 'koneksi.php';

// Proteksi halaman admin
if (!isset($_SESSION['admin_vault'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameVault - AdminHMD Template</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=4">
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">
                <img src="assets/img/logo.jpg" alt="GameVault">
            </div>
            <div class="brand-text">
                <h2>GameVault</h2>
                <span>Admin Template</span>
            </div>
        </div>
        
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
            
            <li class="menu-header">GameVault Engine</li>
            <li><a href="manajemen_game.php"><i class="fa-solid fa-gamepad"></i> Manajemen Game</a></li>
            <li><a href="kategori.php"><i class="fa-solid fa-layer-group"></i> Kategori Game</a></li>
            <li><a href="transaksi.php"><i class="fa-solid fa-money-bill-transfer"></i> Transaksi Order</a></li>
            <li><a href="laporan.php"><i class="fa-solid fa-print"></i> Laporan Penjualan</a></li>
            
            <li class="menu-header">Akses Pengguna</li>
            <li><a href="user.php"><i class="fa-solid fa-users"></i> Users</a></li>
            <li><a href="tambah_user.php"><i class="fa-solid fa-user-plus"></i> Tambah User</a></li>
            <li><a href="profile.php"><i class="fa-solid fa-user-gear"></i> Profile</a></li>
            
            <li class="menu-header">Template Elements</li>
            <li><a href="charts.php"><i class="fa-solid fa-chart-line"></i> Charts</a></li>
            <li><a href="tables.php"><i class="fa-solid fa-table"></i> Tables</a></li>
            <li><a href="forms.php"><i class="fa-solid fa-file-invoice"></i> Forms</a></li>
            <li><a href="components.php"><i class="fa-solid fa-cubes"></i> Components</a></li>
            <li><a href="alerts.php"><i class="fa-solid fa-triangle-exclamation"></i> Alerts</a></li>
            <li><a href="modals.php"><i class="fa-solid fa-window-maximize"></i> Modals</a></li>
            
            <li class="menu-header">Sistem</li>
            <li><a href="settings.php"><i class="fa-solid fa-gear"></i> Settings</a></li>
        </ul>

        <div class="sidebar-user-box">
            <div class="user-avatar-circle">AV</div>
            <div class="user-detail-text">
                <span class="user-name"><?= $_SESSION['admin_vault']; ?></span>
                <span class="user-status"><i class="fa-solid fa-circle"></i> Online</span>
            </div>
            <a href="logout.php" class="quick-logout" title="Keluar Aplikasi">
                <i class="fa-solid fa-power-off"></i>
            </a>
        </div>
    </div>

    <div class="main-content">
        <header>
            <div class="header-left">
                <button class="menu-toggle-btn"><i class="fa-solid fa-bars"></i></button>
                <div class="search-bar-container">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" placeholder="Search users, orders, reports...">
                </div>
            </div>
            <div class="header-right">
                <button class="top-action-btn"><i class="fa-solid fa-sun"></i></button>
                <button class="top-action-btn notif"><i class="fa-solid fa-bell"></i><span class="dot"></span></button>
                <div class="top-profile-badge">
                    <div class="avatar-small"></div>
                    <span>Admin Vault</span>
                </div>
            </div>
        </header>
        <div class="content">