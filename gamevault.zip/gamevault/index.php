<?php 
include 'header_sidebar.php'; 

$q_game = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM game");
$r_game = mysqli_fetch_assoc($q_game);

$q_income = mysqli_query($koneksi, "SELECT SUM(total_bayar) as total FROM transaksi WHERE status_order='Selesai'");
$r_income = mysqli_fetch_assoc($q_income);

$q_trx = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM transaksi WHERE status_order='Pending'");
$r_trx = mysqli_fetch_assoc($q_trx);
?>

<div style="display: flex; gap: 20px; margin-bottom: 20px;">
    <div class="card" style="flex: 1; border-left: 4px solid #3498db;">
        <h3 style="color: #7f8c8d; font-size: 14px; text-transform: uppercase;">Total Game</h3>
        <p style="font-size: 28px; font-weight: bold; margin-top: 10px; color: #2c3e50;"><?= $r_game['total']; ?></p>
    </div>
    <div class="card" style="flex: 1; border-left: 4px solid #18bc9c;">
        <h3 style="color: #7f8c8d; font-size: 14px; text-transform: uppercase;">Total Pendapatan</h3>
        <p style="font-size: 28px; font-weight: bold; margin-top: 10px; color: #2c3e50;">Rp <?= number_format($r_income['total'], 0, ',', '.'); ?></p>
    </div>
    <div class="card" style="flex: 1; border-left: 4px solid #f39c12;">
        <h3 style="color: #7f8c8d; font-size: 14px; text-transform: uppercase;">Transaksi Pending</h3>
        <p style="font-size: 28px; font-weight: bold; margin-top: 10px; color: #2c3e50;"><?= $r_trx['total']; ?></p>
    </div>
</div>

<div class="card">
    <h3>3 Transaksi Terakhir (Live MySQL Data)</h3>
    <table>
        <tr><th>ID Order</th><th>Tanggal</th><th>Total Bayar</th><th>Status</th></tr>
        <?php
        $tampil = mysqli_query($koneksi, "SELECT * FROM transaksi ORDER BY tanggal_transaksi DESC LIMIT 3");
        while ($data = mysqli_fetch_array($tampil)) {
            $status_class = $data['status_order'] == 'Selesai' ? 'badge-success' : 'badge-warning';
            echo "<tr>
                    <td>{$data['id_order']}</td>
                    <td>{$data['tanggal_transaksi']}</td>
                    <td>Rp ".number_format($data['total_bayar'], 0, ',', '.')."</td>
                    <td><span class='badge {$status_class}'>{$data['status_order']}</span></td>
                  </tr>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>