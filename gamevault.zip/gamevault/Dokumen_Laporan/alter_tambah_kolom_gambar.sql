-- Jalankan query ini di phpMyAdmin (tab SQL) pada database gamevault_db
-- untuk menambahkan kolom gambar pada tabel game.

ALTER TABLE `game`
  ADD COLUMN `gambar_game` VARCHAR(255) DEFAULT NULL AFTER `deskripsi`;
