-- =========================================================
-- MIGRASI DATABASE GAMEVAULT
-- Jalankan SEMUA query di bawah ini di phpMyAdmin (tab SQL)
-- pada database gamevault_db.
--
-- Catatan: query ini aman dijalankan ulang (idempotent),
-- jadi tidak akan error walaupun pernah dijalankan sebelumnya.
-- =========================================================

-- 1) Tambah kolom gambar pada tabel game (untuk fitur upload foto game)
--    Jika kolom sudah ada, lewati / hapus baris ini sebelum menjalankan.
ALTER TABLE `game`
  ADD COLUMN `gambar_game` VARCHAR(255) DEFAULT NULL AFTER `deskripsi`;

-- 2) Buat tabel pengaturan toko (untuk halaman Settings)
CREATE TABLE IF NOT EXISTS `pengaturan_toko` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_toko` varchar(100) NOT NULL DEFAULT 'GameVault',
  `email_kontak` varchar(100) DEFAULT NULL,
  `nomor_wa` varchar(20) DEFAULT NULL,
  `deskripsi_toko` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pengaturan_toko` (`id`, `nama_toko`, `email_kontak`, `nomor_wa`, `deskripsi_toko`)
VALUES (1, 'GameVault', 'admin@gamevault.com', '', 'Toko digital game dan voucher top-up terpercaya.')
ON DUPLICATE KEY UPDATE id = id;
