# Dokumen Perancangan Sistem GameVault

Sesuai dengan ketentuan tugas pada gambar, berikut adalah draft rancangan sistem yang dapat digunakan untuk menyusun laporan Anda.

## 1. Use Case Diagram
Aktor: Admin, Customer
Use Case Admin:
- Melakukan Login
- Mengelola Data Game (Tambah, Edit, Hapus)
- Mengelola Kategori
- Melihat dan Mengonfirmasi Transaksi Order
- Mengelola User
- Mencetak Laporan Penjualan

## 2. Activity Diagram (Alur Penjualan / Transaksi)
1. Customer memilih game di platform.
2. Customer melakukan checkout dan pembayaran.
3. Sistem membuat status pesanan "Pending".
4. Admin login ke Dashboard GameVault.
5. Admin membuka menu "Transaksi Order".
6. Admin melakukan verifikasi pembayaran dan klik "Konfirmasi".
7. Sistem mengubah status menjadi "Selesai" dan mengirimkan Game Key ke Customer.

## 3. Sequence Diagram (Login Admin)
1. Admin memasukkan Username dan Password di halaman `login.html`.
2. Sistem memvalidasi kredensial.
3. Jika valid, sistem membuat session.
4. Sistem mengarahkan Admin ke `index.html` (Dashboard GameVault).
